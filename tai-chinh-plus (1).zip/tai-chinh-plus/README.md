# Tài Chính+ — website demo

Website tĩnh tiếng Việt dành cho nội dung tài chính cá nhân. Giao diện responsive, dark mode, tìm kiếm demo, lọc bài viết, newsletter demo và 2 công cụ tính toán chạy bằng JavaScript.

## Chạy thử
Mở `index.html` trực tiếp trên trình duyệt hoặc chạy local server:

```bash
python -m http.server 8000
```

Sau đó mở `http://localhost:8000`.

## Khi đưa lên production
- Kết nối CMS (WordPress/Headless CMS) nếu muốn đăng hàng trăm bài.
- Thay dữ liệu minh họa trong sidebar bằng API dữ liệu hợp pháp/được cấp phép.
- Thêm Google Search Console + GA4.
- Chỉ triển khai quảng cáo sau khi site có nội dung và tuân thủ chính sách mạng quảng cáo.
- Bổ sung trang `/privacy`, `/terms`, `/contact`, và thông tin đơn vị vận hành.
