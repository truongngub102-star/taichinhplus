const $=s=>document.querySelector(s);const $$=s=>document.querySelectorAll(s);
function fmt(n){return new Intl.NumberFormat('vi-VN',{style:'currency',currency:'VND',maximumFractionDigits:0}).format(n)}
$('#compoundBtn').addEventListener('click',()=>{const P=+$('#principal').value||0,M=+$('#monthly').value||0,r=(+$('#rate').value||0)/100/12,n=Math.max(0,(+$('#years').value||0))*12;let fv=P*Math.pow(1+r,n);if(r===0)fv+=M*n;else fv+=M*(Math.pow(1+r,n)-1)/r;$('#compoundResult').textContent='Giá trị minh họa sau thời gian trên: '+fmt(fv)});
$('#fundBtn').addEventListener('click',()=>{const e=+$('#expense').value||0,m=+$('#months').value||0;$('#fundResult').textContent='Mục tiêu quỹ dự phòng: '+fmt(e*m)});
$('#newsletterForm').addEventListener('submit',e=>{e.preventDefault();$('#formMsg').textContent='Đăng ký thành công (demo).';e.target.reset();showToast('Đã đăng ký bản tin thử nghiệm');});
$('#searchBtn').addEventListener('click',()=>{const q=$('#searchInput').value.trim();if(!q){showToast('Hãy nhập từ khóa để tìm bài');return}showToast('Đang tìm: '+q);document.querySelector('#latest').scrollIntoView({behavior:'smooth'});});
$('#searchInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('#searchBtn').click()});
$$('.tab').forEach(btn=>btn.addEventListener('click',()=>{ $$('.tab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const f=btn.dataset.filter;$$('.article-card').forEach(c=>{const ok=f==='all'||c.dataset.cat===f;c.style.display=ok?'block':'none'});}));
$('#themeBtn').addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.setItem('tc-theme',document.body.classList.contains('dark')?'dark':'light')});if(localStorage.getItem('tc-theme')==='dark')document.body.classList.add('dark');
function showToast(t){const el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2200)}
// Demo placeholders: replace with live market/news API when deploying.
